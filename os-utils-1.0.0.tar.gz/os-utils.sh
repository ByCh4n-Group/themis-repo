#!/bin/bash

checkroot() {
   reset='\033[0m'
   red='\033[0;31m'
   green='\033[0;32m'
    if [[ ${EUID} != 0 ]] ; then
            echo -e "${red}pls try with root privalages 'sudo ${0}'${reset}"
            checkroot="false"
            [[ ${1} =~ ^(exit|EXIT|--exit|--EXIT|-e)$ ]] && exit 1
        else
            echo -e "${green}set user have super cow powers....${reset}"
            checkroot="true"
    fi
}

definebase() {
    if [ -e /etc/debian_version ] ; then
        set_systembase="debian"
    elif [ -e /etc/arch-release ] ; then
        set_systembase="arch"
    elif [ -e /etc/artix-release ] ; then
        set_systembase="arch"
    elif [ -e /etc/fedora-release ] ; then
        set_systembase="fedora"
    elif [ -e /etc/pisi-release ] ; then
        set_systembase="pisi"
    elif [ -e /etc/zypp/zypper.conf ] ; then
        set_systembase="opensuse"
    else
        set_systembase="unknow"
    fi
}

updatecatalogs() {
    up() {
        checkroot -e
        netcheck "e"
        definebase
        case ${set_systembase} in
            debian)
                apt update
            ;;
            arch)
                pacman -Syyy
            ;;
            fedora)
                dnf check-update
            ;;
            pisi)
                pisi ur
            ;;
            opensuse)
                zypper refresh
            ;;
        esac
    }
    if [ -e ~/.lastupdate.conf ] ; then
        source ~/.lastupdate.conf
        if [[ $(date +%Y%m%d) -gt $(( ${lastupdate} + 7 )) ]] ; then
            up
            echo "lastupdate='$(date +%Y%m%d)'" > ~/.lastupdate.conf
        else
            echo "Catalogs Are Up To Date."
        fi 
    else
        up
        echo "lastupdate='$(date +%Y%m%d)'" > ~/.lastupdate.conf
    fi
}

installpkg() {
    updatecatalogs
    checkroot -e
    netcheck "e"
    definebase
    case ${set_systembase} in
        debian)
            apt install -y ${1}
        ;;
        arch)
            pacman -Sy --noconfirm ${1}
        ;;
        fedora)
            dnf install -y ${1}
        ;;
        pisi)
            pisi it -y ${1}
        ;;
        opensuse)
            echo "${1}"
            zypper install --no-confirm ${1}
        ;;
    esac

}

check() {
    error() {
        echo -e "${red}[-] Error Occured${reset}: ${1}"
        [[ ${2} = "fatal" ]] && exit 1
    }

    case ${1} in
        d)
            for i in $(seq 2 ${#}) ; do 
                [[ -d "${@:i:1}" ]] || error "Directory ${@:i:1} not found!" fatal
            done
        ;;
        f)
            for i in $(seq 2 ${#}) ; do 
                [[ -f "${@:i:1}" ]] || error "File ${@:i:1} not found!" fatal
            done
        ;;
        t)
            for i in $(seq 2 ${#}) ; do 
                [[ $(command -v ${@:i:1}) ]] || error "Trigger ${@:i:1} not found! Please install that package." fatal
            done
        ;;
        *)
            warn "module ${0}: Called function ${FUNCNAME}: Wrong usage."
        ;;
    esac
}
